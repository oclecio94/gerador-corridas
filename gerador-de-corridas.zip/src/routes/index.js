import { corridaRoutes } from "./corrida.routes.js";

const routes = (app) => {
  corridaRoutes(app);
};

export default routes;
