export default {
  transform: {},
  testEnvironment: "node",
};
